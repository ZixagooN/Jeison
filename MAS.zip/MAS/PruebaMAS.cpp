#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;

//Defino las variables que se usaran
    int op;
    double pi=3.141598;
    double E;
    double t=0.0;
    double A=0.751;
    double h=0.001;
    double tf=18.0;
    double u=0.0;
    int j=0;
    string num1;

//Defino las EDOS a la que le aplicamos el metodo 
//u: Velocidad , x: Posición
double EDO1(double u){
    return u;
}
double EDO2(double w,double x){
    return -(w*w*x);
}
string D;
std::ofstream datafile("Resorte.dat");
std::ofstream datafile2("Errores.dat");
//Funcion euler
double Euler(double x, double m, double T){
    ifstream inputFile(D); 
    double k=(4*pi*pi*m)/(T*T);
    double w=sqrt(k/m);
    getline(inputFile, num1, ' ');
    float tiempo = stod(num1);
    for (double i = t; i <= tf; i=i+h ){
        j=j+1;
        double errorx;
        double errorv;
        double errorE;
        double valorexp;
        float tiemponumerico=i;
        if(j==1 && tiemponumerico==tiempo){
            j=j+1;
            if(j==2){
            getline(inputFile, num1, ' ');
            double valorexp=stod(num1);
            errorx=abs(valorexp-x);

        }
            j=j+1;
            if(j==3){
            getline(inputFile, num1, ' ');
            double valorexp=stod(num1);
            errorv=abs(valorexp-u);

        }
            j=j+1;
            if(j==4){
                getline(inputFile, num1, ' ');
                j=0;
                double valorexp=stod(num1);
                errorE=abs(valorexp-E);
            getline(inputFile, num1, ' ');
        }
        datafile2<<tiempo<<"  "<<errorx<<"  "<<errorv<<"  "<<errorE<<std::endl;
        tiempo=stod(num1);
        }
        datafile<<i<<"  "<<x<<"  "<<u<<"  "<<E<<std::endl;
        u=u+EDO2(w,x)*h;
        x=x+EDO1(u)*h;
        E=0.5*(m*u*u+k*x*x)*pow(10,-4);
        j=0;
    }
    datafile2.close();
    datafile.close();
    inputFile.close();
return 0;
}

//Funcion euler mejorado
double EulerM(double x, double m, double T){
    ifstream inputFile(D); 
    double k=(4*pi*pi*m)/(T*T);
    double w=sqrt(k/m);
    getline(inputFile, num1, ' ');
    float tiempo = stod(num1);
    for (double i = t; i <= tf; i=i+h ){
        j=j+1;
        double errorx;
        double errorv;
        double errorE;
        double valorexp;
        float tiemponumerico=i;
        if(j==1 && tiemponumerico==tiempo){
            j=j+1;
            if(j==2){
            getline(inputFile, num1, ' ');
            double valorexp=stod(num1);
            errorx=abs(valorexp-x);

        }
            j=j+1;
            if(j==3){
            getline(inputFile, num1, ' ');
            double valorexp=stod(num1);
            errorv=abs(valorexp-u);

        }
            j=j+1;
            if(j==4){
                getline(inputFile, num1, ' ');
                j=0;
                double valorexp=stod(num1);
                errorE=abs(valorexp-E);
            getline(inputFile, num1, ' ');
        }
        datafile2<<tiempo<<"  "<<errorx<<"  "<<errorv<<"  "<<errorE<<std::endl;
        tiempo=stod(num1);
        }
        datafile<<i<<"  "<<x<<"  "<<u<<"  "<<E<<std::endl;
        double x_a=x+EDO1(u)*h;
        double u_a=u+EDO2(w,x)*h;
        x=x+0.5*h*(EDO1(u)+EDO1(u_a));
        u=u+0.5*h*(EDO2(w,x_a)+EDO2(w,x));
        E=0.5*(m*u*u+k*x*x)*pow(10,-4);
        j=0;
        }
    datafile.close();
    return 0;
} 

//Funcion Runge Kutta
double RungeKutta(double x, double m, double T){
    ifstream inputFile(D); 
    double k=(4*pi*pi*m)/(T*T);
    double w=sqrt(k/m);
    getline(inputFile, num1, ' ');
    float tiempo = stod(num1);
     for (double i = t; i <= tf; i=i+h ){
        double k1u=h*EDO2(w,x);
        double k2u=h*EDO2(w,x+0.5*k1u);
        double k3u=h*EDO2(w,x+0.5*k2u);
        double k4u=h*EDO2(w,x+k3u);
        double k1x=h*EDO1(u);
        double k2x=h*EDO1(u+0.5*k1x);
        double k3x=h*EDO1(u+0.5*k2x);
        double k4x=h*EDO1(u+k3x);
        j=j+1;
        double errorx;
        double errorv;
        double errorE;
        double valorexp;
        float tiemponumerico=i;
        if(j==1 && tiemponumerico==tiempo){
            j=j+1;
            if(j==2){
            getline(inputFile, num1, ' ');
            double valorexp=stod(num1);
            errorx=abs(valorexp-x);

        }
            j=j+1;
            if(j==3){
            getline(inputFile, num1, ' ');
            double valorexp=stod(num1);
            errorv=abs(valorexp-u);

        }
            j=j+1;
            if(j==4){
                getline(inputFile, num1, ' ');
                j=0;
                double valorexp=stod(num1);
                errorE=abs(valorexp-E);
            getline(inputFile, num1, ' ');
        }
        datafile2<<tiempo<<"  "<<errorx<<"  "<<errorv<<"  "<<errorE<<std::endl;
        tiempo=stod(num1);
        }
        datafile<<i<<"  "<<x<<"  "<<u<<"  "<<E<<std::endl;
        x=x+(1.0/6.0)*(k1x+(2*k2x)+(2*k3x)+ k4x);
        u=u+(1.0/6.0)*(k1u+(2*k2u)+(2*k3u)+ k4u);
        E=0.5*(m*u*u+k*x*x)*pow(10,-4);
        j=0;
    }
        datafile.close();
    return 0;
}

double MenuMetodosNumericos(){
    std::cout<<"Seleccione el metodo numerico."<<std::endl;
    std::cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<std::endl;
    std::cout<<"1. Aproximación Numérica Metodo de Euler y Experimental."<<std::endl;
    std::cout<<"2. Aproximación Numérica Metodo de Euler Mejorado y Experimental."<<std::endl;
    std::cout<<"3. Aproximación Numérica Metodo de Runge Kutta y Experimental."<<std::endl;
    std::cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<std::endl;
    std::cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<std::endl;
    std::cout<<"Ingrese su opción"<<std::endl;
    return 0;
}

double Script1(int var){
    std::ofstream scriptFile1("grafica_aproximada.gp");
    scriptFile1<<"set term png\n";
    scriptFile1<<"set output 'Error Absoluto x(t).png'\n";
    scriptFile1<<"set xlabel 't'\n";
    scriptFile1<<"set ylabel 'Error Absoluto'\n";
    scriptFile1<<"plot 'Errores.dat' u 1:2 w l lc rgb 'red' title 'Error absoluto de X'\n"; 

    scriptFile1<<"set output 'Error Absoluto v(t).png'\n";
    scriptFile1<<"set xlabel 't'\n";
    scriptFile1<<"set ylabel 'Error Absoluto'\n";
    scriptFile1<<"plot 'Errores.dat' u 1:3 w l lc rgb 'violet' title 'Error absoluto de V'\n"; 

    scriptFile1<<"set output 'Error Absoluto E(t).png'\n";
    scriptFile1<<"set xlabel 't'\n";
    scriptFile1<<"set ylabel 'Error Absoluto'\n";
    scriptFile1<<"plot 'Errores.dat' u 1:4 w l lc rgb 'blue' title 'Error Absoluto de E'\n"; 

    scriptFile1<<"set output 'Error Absoluto.png'\n";
    scriptFile1<<"set xlabel 't'\n";
    scriptFile1<<"set ylabel 'Error Absoluto'\n";  
    scriptFile1<<"plot 'Errores.dat' u 1:2 w l lc rgb 'red' title 'Error absoluto de X', 'Errores.dat' u 1:3 w l lc rgb 'violet' title 'Error absoluto de V', 'Errores.dat' u 1:4 w l lc rgb 'blue' title 'Error Absoluto de E'\n"; 

    scriptFile1<<"set output 'Oscilacion x(t).png'\n";
    scriptFile1<<"set xlabel 't'\n";
    scriptFile1<<"set ylabel 'x'\n";
    scriptFile1<<"set xrange [0:18]\n";
    switch(var){
        case 1:      
            scriptFile1<<"plot 'Resorte.dat' u 1:2 w l lc rgb 'red' title 'Solución Aproximada', 'Datos100.txt' u 1:2 w l lc rgb 'blue' title 'Grafica Experimental'\n";
            scriptFile1<<"set output 'Oscilacion v(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'v'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:3 w l lc rgb 'red' title 'Solución Aproximada',  'Datos100.txt' u 1:3 w l lc rgb 'blue' title 'Grafica Experimental'\n";  

            scriptFile1<<"set output 'Oscilacion E(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'E'\n";
            scriptFile1<<"plot 'Resorte.dat' u 1:4 w l lc rgb 'red' title 'Solución Aproximada', 'Datos100.txt' u 1:4 w l lc rgb 'blue' title 'Grafica Experimental'\n";

        scriptFile1.close();
        break;
        case 2:
            scriptFile1<<"plot 'Resorte.dat' u 1:2 w l lc rgb 'red' title 'Solución Aproximada', 'Datos200.txt' u 1:2 w l lc rgb 'blue' title 'Grafica Experimental'\n";
            scriptFile1<<"set output 'Oscilacion v(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'v'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:3 w l lc rgb 'red' title 'Solución Aproximada', 'Datos200.txt' u 1:3 w l lc rgb 'blue' title 'Grafica Experimental'\n";  
            scriptFile1<<"set output 'Oscilacion E(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'E'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:4 w l lc rgb 'red' title 'Solución Aproximada', 'Datos200.txt' u 1:4 w l lc rgb 'blue' title 'Grafica Experimental'\n";  

        scriptFile1.close();
        break;
        case 3:
            scriptFile1<<"plot 'Resorte.dat' u 1:2 w l lc rgb 'red' title 'Solución Aproximada', 'Datos250.txt' u 1:2 w l lc rgb 'blue' title 'Grafica Experimental'\n";
            scriptFile1<<"set output 'Oscilacion v(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'v'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:3 w l lc rgb 'red' title 'Solución Aproximada', 'Datos250.txt' u 1:3 w l lc rgb 'blue' title 'Grafica Experimental'\n";  
            scriptFile1<<"set output 'Oscilacion E(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'E'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:4 w l lc rgb 'red' title 'Solución Aproximada', 'Datos250.txt' u 1:4 w l lc rgb 'blue' title 'Grafica Experimental'\n";     
        scriptFile1.close();
        break;
        case 4:
            scriptFile1<<"set xrange [0:17]";
            scriptFile1<<"plot 'Resorte.dat' u 1:2 w l lc rgb 'red' title 'Solución Aproximada', 'Datos270.txt' u 1:2 w l lc rgb 'blue' title 'Grafica Experimental'\n";
            scriptFile1<<"set output 'Oscilacion v(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'v'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:3 w l lc rgb 'red' title 'Solución Aproximada', 'Datos270.txt' u 1:3 w l lc rgb 'blue' title 'Grafica Experimental'\n";  
            scriptFile1<<"set output 'Oscilacion E(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'E'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:4 w l lc rgb 'red' title 'Solución Aproximada', 'Datos270.txt' u 1:4 w l lc rgb 'blue' title 'Grafica Experimental'\n";     
        break;
        case 5:
            scriptFile1<<"set xrange [0:14]\n";
            scriptFile1<<"plot 'Resorte.dat' u 1:2 w l lc rgb 'red' title 'Solución Aproximada', 'Datos280.txt' u 1:2 w l lc rgb 'blue' title 'Grafica Experimental'\n";
            scriptFile1<<"set output 'Oscilacion v(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'v'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:3 w l lc rgb 'red' title 'Solución Aproximada', 'Datos280.txt' u 1:3 w l lc rgb 'blue' title 'Grafica Experimental'\n";  
            scriptFile1<<"set output 'Oscilacion E(t).png'\n";
            scriptFile1<<"set xlabel 't'\n";
            scriptFile1<<"set ylabel 'E'\n";  
            scriptFile1<<"plot 'Resorte.dat' u 1:4 w l lc rgb 'red' title 'Solución Aproximada', 'Datos280.txt' u 1:4 w l lc rgb 'blue' title 'Grafica Experimental'\n";                 
        scriptFile1.close();
        break;
    }

    return 0;
}

int main() {
    std::cout<<"Soluciones a la ecuación diferencial del movimiento armonico simple."<<std::endl;
    std::cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<std::endl;
    std::cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<std::endl;
    std::cout<<"1. Experimento Masa 100g."<<std::endl;
    std::cout<<"2. Experimento Masa 200g."<<std::endl;
    std::cout<<"3. Experimento Masa 250g."<<std::endl;
    std::cout<<"4. Experimento Masa 270g."<<std::endl;
    std::cout<<"5. Experimento Masa 280g."<<std::endl;
    std::cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<std::endl;
    std::cout<<"Ingrese su opción"<<std::endl;
    std::cin>>op;
    switch (op)
    {
    case 1://Experimento 1
    MenuMetodosNumericos();
    std::cin>>op;
    D="Datos100.txt";
    switch (op){
        case 1: //Euler
        Euler(10.54, 0.1, 0.751);
        break;
        case 2: //EulerMejorado
        EulerM(10.54, 0.1, 0.751);
        break;
        case 3: //RungeKutta
        RungeKutta(10.54, 0.1, 0.751);
        break;
    }
    Script1(1);
        break;
    case 2://Experimento 2
        MenuMetodosNumericos();
        std::cin>>op;
        D="Datos200.txt";
        switch (op){
            case 1: //Euler
            Euler(7.894, 0.2, 1.034);
            break;
            case 2: //EulerMejorado
            EulerM(7.894, 0.2, 1.034);
            break;
            case 3: //RungeKutta
            RungeKutta(7.894, 0.2, 1.034);
            break;
        }
        Script1(2);
            break;
    case 3://Experimento 3
        MenuMetodosNumericos();
        std::cin>>op;
        D="Datos250.txt";
        switch (op){
            case 1: //Euler
            Euler(9.039, 0.250, 1.136);
            break;
            case 2: //EulerMejorado
            EulerM(9.039, 0.250, 1.136);
            break;
            case 3: //RungeKutta
            RungeKutta(9.039, 0.250, 1.136);
            break;
        }
        Script1(3);
            break;
    case 4://Experimento 4
        MenuMetodosNumericos();
        std::cin>>op;
        D="Datos270.txt";
        switch (op){
            case 1: //Euler
            Euler(7.865, 0.270, 1.184);
            break;
            case 2: //EulerMejorado
            EulerM(7.865, 0.270, 1.184);
            break;
            case 3: //RungeKutta
            RungeKutta(7.865, 0.270, 1.184);
            break;
        }
        Script1(4);
            break;
    case 5://Experimento 5
        MenuMetodosNumericos();
        std::cin>>op;
        D="Datos280.txt";
        switch (op){
            case 1: //Euler
            Euler(6.067, 0.280, 1.201);
            break;
            case 2: //EulerMejorado
            EulerM(6.067, 0.280, 1.201);
            break;
            case 3: //RungeKutta
            RungeKutta(6.067, 0.280, 1.201);
            break;
        }
        Script1(5);
        break;
    default:
        std::cout<<"arepuela"<<std::endl;
        break;
    }

    system("gnuplot grafica_aproximada.gp");
    return 0;
}